import numpy as np
import pandas as pd
import torch
import os
from torch.utils.data import DataLoader, Dataset

#from Vegetable.conf.conf import Conf
import click

class VegetableDataloder(Dataset):
    def __init__(self, encoder_input, decoder_input):

        self.encoder_input = encoder_input
        self.decoder_input = decoder_input

    def __len__(self):
        return len(self.decoder_input)

    def __getitem__(self, item):
        return {
            "encoder_input" : torch.tensor(self.encoder_input[item], dtype=torch.float32),
            "decoder_input" : torch.tensor(self.decoder_input[item], dtype=torch.float32)
        }


def preprocessing(cnf):
    cnf_ = cnf
    data = pd.read_csv('./data/public_data/train.csv')

    week_day_map = {}
    for i, d in enumerate(data['요일'].unique()):
        week_day_map[d] = i
    data['요일'] = data['요일'].map(week_day_map)
    norm = data.iloc[:, 1:].max(0)
    data.iloc[:, 1:] = data.iloc[:, 1:] / norm
    x_data = []
    y_data = []
    for i in range(data.shape[0] - cnf_.all_params["encoder_length"] - cnf_.all_params["decoder_length"]):
        x = data.iloc[i:i + cnf_.all_params["decoder_length"], 1:].to_numpy()
        y = data.iloc[i + cnf_.all_params["encoder_length"]:i + cnf_.all_params["encoder_length"] + cnf_.all_params["decoder_length"], 3::2].to_numpy()
        y_0 = np.zeros([1, y.shape[1]])  # 디코더 첫 입력값 추가
        x_data.append(x)
        y_data.append(np.concatenate([y_0, y], axis=0))
    x_data = np.array(x_data)
    y_data = np.array(y_data)
    train_test_split = 1
    x_train = x_data[:-train_test_split - cnf_.all_params["decoder_length"]]
    y_train = y_data[:-train_test_split - cnf_.all_params["decoder_length"]]
    x_val = x_data[-train_test_split:]
    y_val = y_data[-train_test_split:]
    return x_train, y_train, x_val, y_val


@click.command()
@click.option('--conf_file_path', type=str, default="./conf/dacon_data.yaml")
def main(conf_file_path):

    from conf import Conf

    cnf = Conf(conf_file_path= conf_file_path, seed = 20205289)
    x_train, y_train, x_val, y_val  = preprocessing(cnf)
#    train_dataset = VegetableDataloder(x_train, y_train)
#    val_dataset = VegetableDataloder(x_val, y_val)
    return x_train, y_train, x_val, y_val


if __name__ == '__main__':
    main()